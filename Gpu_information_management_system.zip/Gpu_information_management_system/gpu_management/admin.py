from django.contrib import admin
from .models import  GPU, GPUReserve

# Register GPU
class GPUAdmin(admin.ModelAdmin):
    list_display = ('name', 'id', 'amount')
    search_fields = ('name', 'id')

admin.site.register(GPU, GPUAdmin)

# Register Management
class GPUReserveAdmin(admin.ModelAdmin):
    list_display = ('user', 'gpu', 'amount', 'duration', 'status','start_time','end_time','is_expired')
    search_fields = ('user__username', 'gpu', 'status')
    list_filter = ('status',)

admin.site.register(GPUReserve, GPUReserveAdmin)
