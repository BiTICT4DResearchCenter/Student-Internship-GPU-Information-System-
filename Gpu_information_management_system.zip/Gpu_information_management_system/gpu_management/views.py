from django.contrib.auth.decorators import login_required,permission_required
from django.shortcuts import render, redirect,get_object_or_404
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Sum,Value,Q
from .tasks import update_expired_reservations
from django.http import JsonResponse
from guardian.shortcuts import assign_perm
from django.http import JsonResponse
from django.db import transaction
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.utils import timezone


from .models import GPUReserve
from .forms import GPUReserveForm
from user.models import CustomUser,PermissionDelegation


def has_delegeted_permission(user,permission_codename):
    return PermissionDelegation.objects.filter(
        delegatee=user,permission=permission_codename,start_date__lt=timezone.now(),
        end_date__gte=timezone.now() if 'end_date' else timezone.now()).exists()
    
@login_required
def create_gpu_reserve(request):
    update_expired_reservations()
    user=request.user
    existing_reservation = GPUReserve.objects.filter(
        Q(user=user)&
        Q(is_expired=False)&
        Q(status__in=['APPROVED', 'PENDING'])
    ).exists()

    if existing_reservation:
        return redirect('reserve_response')



    if request.method == 'POST':
        form = GPUReserveForm(request.POST)
        if form.is_valid():
            start_date = form.cleaned_data['start_time']
            duration = form.cleaned_data['duration']

            end_date = start_date + duration
            gpu = form.cleaned_data['gpu']
            request_amount = form.cleaned_data['amount']

            reserved_total_gpu = GPUReserve.objects.filter(
                Q(is_expired=Value(False))&
                Q(start_time__lt=end_date)&
                    Q(end_time__gt=start_date)&
                    ~Q(status='REJECTED')&
                    Q(gpu=gpu  )
        ).aggregate(total_reserved=Sum('amount'))['total_reserved'] or 0
            
            request_gpu = gpu.amount  
            available_gpu = request_gpu - reserved_total_gpu

            if available_gpu >= request_amount:
                gpu_order = form.save(commit=False)
                gpu_order.end_time = end_date  
                gpu_order.user = request.user 

                with transaction.atomic():
                    gpu_order.save()  
                    staff_associated = request.user.staff
                    staff_admins = CustomUser.objects.filter(staff=staff_associated, role="staff_admin")

                    for staff_admin in staff_admins:
                        try:
                            assign_perm('gpu_management.manage_reserve', staff_admin, gpu_order)  
                        except Exception as e:
                            print(f"Failed to assign permission: {e}")
                
                return redirect('reserve_response')  
            else:
                form.add_error('amount', 'Not enough GPUs available for the requested duration.')
    else:
        form = GPUReserveForm()
    return render(request, 'researcher_page/gpu_reserve.html', {'form': form,})  





@login_required
def reserve_response(request):
     user=request.user
     try:
        reserve=GPUReserve.objects.filter(user=user).latest('reservered_at')
     except ObjectDoesNotExist:
        reserve=None
     return render(request,'researcher_page/reserve_response.html',{'reserve':reserve})
 
 
 
@login_required
# @permission_required('gpu_management.manage_reserve', (GPUReserve, 'id'), raise_exception=True)
def gpu_approval(request, id):
    gpureserve = get_object_or_404(GPUReserve, pk=id)
    if not request.user.has_perm('gpu_management.manage_reserve', gpureserve) and not has_delegeted_permission(request.user, 'manage_reserve'):
        messages.error(request, "Forbidden: You don't have permission to perform this action.")
        return redirect(request.META.get('HTTP_REFERER', '/'))
    if gpureserve.status != 'APPROVED':
        gpureserve.status = 'APPROVED'
        gpureserve.save()
        messages.success(request, f"Reserve '{gpureserve}' has been approved.")
    else:
        messages.warning(request, f"Reserve '{gpureserve}' is already approved.")

    return redirect(request.META.get('HTTP_REFERER', '/'))



@login_required
def gpu_reject(request, id):
    gpureserve = get_object_or_404(GPUReserve, pk=id)
    if not request.user.has_perm('gpu_management.manage_reserve', gpureserve) and not has_delegeted_permission(request.user, 'manage_reserve'):
        messages.error(request, "Forbidden: You don't have permission to perform this action.")
        return redirect(request.META.get('HTTP_REFERER', '/'))

    if gpureserve.status != 'REJECTED':
        gpureserve.status = 'REJECTED'
        gpureserve.save()
        messages.success(request, f"Reserve '{gpureserve}' has been rejected.")
    else:
        messages.warning(request, f"Reserve '{gpureserve}' is already rejected.")

    return redirect(request.META.get('HTTP_REFERER', '/'))


def expire_reservat(request):
    if request.method == 'POST':
        reserve_id = request.POST.get('reserve_id')
        if reserve_id:
            gpureserve = get_object_or_404(GPUReserve, pk=reserve_id)
            gpureserve.is_expired = True
            gpureserve.save()
            return JsonResponse({'status': 'success', 'message': 'Reservation expired.'})
        return JsonResponse({'status': 'error', 'message': 'No reserve_id provided.'}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'}, status=405)
