from . import views  
from django.urls import path

urlpatterns = [
    path('reserve/create/', views.create_gpu_reserve, name='reserve_create'), 
    path('reserve/approve/<int:id>/', views.gpu_approval, name='reserve_approve'), 
    path('reserve/reject/<int:id>/', views.gpu_reject, name='reserve_reject'), 
    path('reserve/response/', views.reserve_response, name='reserve_response'),
    path('expire-reservation/', views.expire_reservat, name='expire_reservat'),
    
    
]
