from django.apps import AppConfig


class GpuManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gpu_management'
