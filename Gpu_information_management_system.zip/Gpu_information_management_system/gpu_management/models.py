from django.db import models
from user.models import CustomUser
from staff.models import Staff 

class GPU(models.Model):
    name = models.CharField(max_length=100 )
    amount = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.name} (ID: {self.id})"

class GPUReserve(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('APPROVED', 'Approved'),
        ('REJECTED', 'Rejected'),

    ]

    user = models.ForeignKey(CustomUser, on_delete=models.PROTECT)  
    gpu = models.ForeignKey(GPU, on_delete=models.PROTECT)     
    amount = models.PositiveIntegerField()
    duration = models.DurationField(default=0)
    status = models.CharField(max_length=55, choices=STATUS_CHOICES, default='PENDING')
    is_using=models.BooleanField(default=False)
    reservered_at=models.DateTimeField(auto_now_add=True)
    is_expired=models.BooleanField(default=False)
    start_time=models.DateTimeField()
    end_time=models.DateTimeField()
    
    class Meta:
        permissions=[
            ("manage_reserve","can manage the reservation"),
        ]
    def __str__(self):
        return f"Management Record: {self.user} - {self.status} - Amount: {self.amount}"


