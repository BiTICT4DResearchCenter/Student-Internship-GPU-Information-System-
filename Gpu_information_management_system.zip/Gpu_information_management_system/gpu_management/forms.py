from django import forms
from datetime import timedelta
from .models import GPUReserve,GPU
from django.core.exceptions import ValidationError
from django.utils import timezone

class GPUReserveForm(forms.ModelForm):
    class Meta:
        model = GPUReserve
        fields = ['gpu', 'amount', 'duration', 'start_time']
        widgets = {
            'start_time': forms.DateTimeInput(attrs={
                'type': 'datetime-local',  
                'class': 'form-control',
            }),
            'duration': forms.TextInput(attrs={
                'placeholder': 'HH:MM:SS',
                'class': 'form-control',
            }),
        }
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['gpu'].queryset = GPU.objects.all()

        if not self.instance.pk: 
            first_gpu = GPU.objects.first()
            if first_gpu:
                self.fields['gpu'].initial = first_gpu 
        
        self.fields['amount'].widget.attrs.update({
            'class': 'form-control', 
            'placeholder': 'Enter amount'
        })

        self.fields['duration'].label = "Duration (HH:MM:SS)"

    def clean_duration(self):
        duration = self.cleaned_data.get('duration')

        if duration is not None:
            if duration.total_seconds() < 0:
                raise forms.ValidationError("Duration must be non-negative.")
        return duration 
    
    def clean_start_time(self):
        start_time = self.cleaned_data['start_time']
        now = timezone.now()
        if start_time < now:
            raise ValidationError("The start time cannot be in the past.")
        return start_time