import logging
from django_q.tasks import schedule
from .models import GPUReserve
from django.utils import timezone
from django.db.models import Q,Value

logger = logging.getLogger(__name__)

def update_expired_reservations():
    logger.info('Executing update_expired_reservations task.')
    now = timezone.now()
    updated_count = GPUReserve.objects.filter(Q(end_time__lt=now) & Q(is_expired=Value(False))).update(is_expired=Value(True))
    logger.info(f'Updated {updated_count} reservations to EXPIRED status.')

schedule('gpu_management.tasks.update_expired_reservations', 
         schedule_type='I',  
         minutes=2)
