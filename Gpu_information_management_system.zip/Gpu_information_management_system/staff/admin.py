from django.contrib import admin
from staff.models import Staff

admin.site.register(Staff)
