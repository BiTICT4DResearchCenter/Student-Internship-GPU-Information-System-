from django.urls import path
from staff import views


urlpatterns = [
    # path('list/', views.staff_list, name='staff-list'),
    path('detail/<int:staff_id>/', views.staff_detail, name='staff-detail'),    
    path('detail/<int:staff_id>/<str:status>/', views.staff_detail, name='staff-detail'),    
    path('dashboard/',views.staff_index,name='staff-index'),
    path('active_user/<int:staff_id>/', views.gpu_active_user, name='reserve_active_user'),
    path('role_transfer/', views.delegate_permission_view, name='role_pass'),
    path('success/', views.success_view, name='success_page'),
]