from django.shortcuts import render,redirect
from django.db.models import Count,Q,Value
from django.contrib.auth.decorators import login_required
from gpu_management.tasks import update_expired_reservations
from guardian.shortcuts import assign_perm,get_objects_for_user,remove_perm
from django.contrib import messages

from gpu_management.models import GPU,GPUReserve
from.models import Staff
from user.forms import PermissionDelegationForm
from user.models import CustomUser

# @login_required
# def staff_list(request):
#         update_expired_reservations()
#         return render(request,'staff_dashboard/staff_list.html',{})


@login_required
def staff_detail(request,staff_id, status=None):
            if request.user.role=='staff_admin':
                if status:
                    update_expired_reservations()
                    reserves=GPUReserve.objects.filter(user__staff_id=staff_id,status=status).order_by('reservered_at')
                else:
                    reserves=GPUReserve.objects.filter(user__staff_id=staff_id).order_by('-reservered_at')
                return render(request, 'staff_dashboard/staff_detail.html', {'requests': reserves,'status':status})
            else:
                return redirect('user-login')


@login_required
def staff_index(request):
        update_expired_reservations() 
        gpus=GPU.objects.all()
        if request.user.role=='staff_admin':
            user=request.user
            staff_id=user.staff.id
            
            
            staffs = (
                Staff.objects.prefetch_related('customuser__gpureserve_set')  
                .annotate(
                    reserve_count=Count(
                        'customuser__gpureserve',
                        filter=Q(customuser__gpureserve__is_expired=Value(False))  
                    ),
                    currently_using=Count(
                        'customuser__gpureserve',  
                        filter=Q(customuser__gpureserve__is_using=Value(True))  
                    ),
                )
                    .values('type', 'id', 'logo', 'reserve_count','currently_using')  
                ) 
            
            
            
            
            current_staff_summary = (
                GPUReserve.objects
                .filter(user__staff_id=staff_id)
                .values("status")  
                .annotate(
                    user_num=Count('id'),  
                )
            )
            return render(request, 'staff_dashboard/staff_index.html', {'staffs':list(staffs),'staff_id':staff_id,'current_staff_summary':list(current_staff_summary),"gpus":gpus})
        else:
            return redirect('user-login')
    
def success_view(request):
    return render(request,'staff_dashboard/success.html',{})

@login_required
def gpu_active_user(request,staff_id):
        update_expired_reservations()
        return render(request,'staff_dashboard/stafff_active_user.html',{})



@login_required
def delegate_permission_view(request):
    if request.method == "POST":
        form = PermissionDelegationForm(request.POST, delegator=request.user)
        if form.is_valid():
            permission_delegation = form.save(commit=False)
            permission_delegation.delegator = request.user
            permission_delegation.save()
            return redirect('success_page')
    else:
        form = PermissionDelegationForm(delegator=request.user)

    return render(request, 'staff_dashboard/staff_role_transfer.html', {'form': form})