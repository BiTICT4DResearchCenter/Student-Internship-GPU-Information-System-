from django import forms
from django.contrib.auth.models import User
from .models import Researcher,CustomUser ,PermissionDelegation
from django.contrib.auth.forms import UserCreationForm

class UserCreateForm(UserCreationForm):

    class Meta:
        model = CustomUser        
        fields = [    'first_name',  'middle_name',  'last_name',  'email',  'phone','staff',  'address','password1','password2', 'image' ]
    def __init__(self, *args, **kwargs):
        super(UserCreateForm, self).__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs.update({'class': 'form-control'})
        self.fields['image'].widget.attrs.update({'class': 'form-control-file'})




class ResearcherForm(forms.ModelForm):
    class Meta:
        model = Researcher
        fields = [
         'gender',  'academic_status',  'faculty',  'department',  'field_of_study',  'sponsorship',  'institution_name_or_company_name', 'thematic_area',  'sub_thematic_area',  'research_approval_letter'
        ]

    def __init__(self, *args, **kwargs):
        super(ResearcherForm, self).__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs.update({'class': 'form-control'})
        self.fields['research_approval_letter'].widget.attrs.update({'class': 'form-control-file'})

   

class UserUpdateForm(forms.ModelForm):
    
    class Meta:
        model = CustomUser
        fields = ['address', 'phone','email',  'image']
    def __init__(self, *args, **kwargs):
        super(UserUpdateForm, self).__init__(*args, **kwargs)
        self.fields['address'].widget.attrs.update({'class': 'form-control'})
        self.fields['phone'].widget.attrs.update({'class': 'form-control'})
        self.fields['image'].widget.attrs.update({'class': 'form-control-file'})  

class ResearcherUpdateForm(forms.ModelForm):
        class Meta:
            model = Researcher
            fields = ['sponsorship']
        def __init__(self, *args, **kwargs):
            super(ResearcherUpdateForm, self).__init__(*args, **kwargs)
            self.fields['sponsorship'].widget.attrs.update({'class': 'form-control'})




class PermissionDelegationForm(forms.ModelForm):
    delegatee =   forms.ModelChoiceField(
        queryset=CustomUser.objects.filter(role='staff_admin'),
        label='Select Staff Admin',
        empty_label="Select a Staff Admin",
        required=True
    )
    
    permission = forms.ChoiceField(
        choices=[
            ('manage_reserve', 'Manage Reserve')
        ],
        label="Permission to Delegate"
    )
    
    end_date = forms.DateTimeField(
        required=False,
        widget=forms.TextInput(attrs={'type': 'date'}),
        label="End Date (optional)"
    )
    
    class Meta:
        model = PermissionDelegation
        fields = ['delegatee', 'permission', 'end_date']

    def __init__(self, *args, **kwargs):
        delegator = kwargs.pop('delegator', None)
        super().__init__(*args, **kwargs)

        if delegator:
            self.fields['delegatee'].queryset = CustomUser.objects.filter(role='staff_admin')