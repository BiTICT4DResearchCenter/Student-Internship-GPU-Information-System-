from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import CustomUser,Researcher,PermissionDelegation

class UserAdmin(BaseUserAdmin):
    model = CustomUser
    list_display = ['email', 'is_staff', 'is_active', 'role','staff','password']
    list_filter = ['is_staff', 'is_active', 'role']
    fieldsets = (
         (None, {'fields': ('email', 'password', 'groups')}),
        ('Personal info', {'fields': ('role', 'address', 'phone', 'middle_name', 'image','staff')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('first_name','last_name','email', 'password1', 'password2', 'role','staff')}
        ),
    )
    search_fields = ['email']
    ordering = ['email']
    filter_horizontal = ('groups', 'user_permissions',)

class ResearcherAdmin(admin.ModelAdmin):
    def get_list_display(self, request):
        return [field.name for field in self.model._meta.get_fields()]
admin.site.register(CustomUser, UserAdmin)
admin.site.register(Researcher,ResearcherAdmin)
admin.site.register(PermissionDelegation)





