from django.shortcuts import render, redirect
from django.contrib.auth import login,logout as auth_logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.urls import reverse
import logging


from .forms import UserCreateForm,UserUpdateForm,ResearcherForm,ResearcherUpdateForm
from .models import  Researcher
from gpu_management.models import GPU
from gpu_management.tasks import update_expired_reservations
logger = logging.getLogger(__name__)

def login_view(request):
    update_expired_reservations()

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            if user.is_authenticated:
                if user.role == 'researcher':
                    return redirect('home') 
                elif user.role == 'staff_admin':
                    return redirect('staff-index') 
                else:
                    return redirect(reverse('admin:index')) 
        else:
            for error in form.non_field_errors():
                messages.error(request, error)
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.capitalize()}: {error}")

            logger.warning(f"Failed login attempt for: {request.POST.get('email')}")

    else:
        form = AuthenticationForm()
    return render(request, 'global/login.html', {'form': form})



@login_required
def home_view(request):
    if request.user.role=='researcher':
        update_expired_reservations()
        gpus=GPU.objects.all()
        return render(request, 'researcher_page/home.html',{"gpus":list(gpus)})
    else:
        return redirect('user-login')


def logout_view(request):
    auth_logout(request)  
    return render(request,'global/logout.html')


# creating researcher with researcher model info
def create_researcher_and_user(request):
    if request.method == 'POST':
        user_form = UserCreateForm(request.POST,request.FILES)
        researcher_form = ResearcherForm(request.POST, request.FILES)
        
        
        if user_form.is_valid() and researcher_form.is_valid():
            user = user_form.save()  
            researcher = researcher_form.save(commit=False)  
            researcher.user = user  
            researcher.save()  
            return redirect('user-profile')  
    else:
        user_form = UserCreateForm()
        researcher_form = ResearcherForm()

    context = {
        'user_form': user_form,
        'researcher_form': researcher_form,
    }
    return render(request, 'researcher_page/create_researcher.html', context)


    
@login_required
def profile(request):
   return render(request,'researcher_page/profile.html')



@login_required
def researcher_profile_update(request):
    user = request.user
    researcher = Researcher.objects.get(user=user)
    
    if request.method == 'POST':
        user_form = UserUpdateForm(request.POST, request.FILES, instance=user)
        researcher_user_form = ResearcherUpdateForm(request.POST, instance=researcher)      
        if user_form.is_valid() and researcher_user_form.is_valid():
            user_form.save()
            researcher_user_form.save()
            return redirect('user-profile') 
    else:
        user_form = UserUpdateForm(instance=request.user)
        try:
            researcher_instance = request.user.researcher  
            researcher_user_form = ResearcherUpdateForm(instance=researcher_instance)
        except Researcher.DoesNotExist:
            researcher_user_form = ResearcherForm() 
    context = {
        'user_form': user_form,
        'reseacher_user_form':researcher_user_form
    }
    return render(request, 'researcher_page/profile_update.html', context)



