from django.urls import path
from .import views 
from django.contrib.auth import views as auth_views
urlpatterns = [
    path('', views.home_view, name='home'),  
    path('user/register/', views.create_researcher_and_user, name='create_researcher'),  
    path('user/login/', views.login_view, name='user-login'),  
    path('user/logout/', views.logout_view, name='user-logout'),  
    path('user/profile/', views.profile, name='user-profile'),
    path('user/profile/update/', views.researcher_profile_update, name='user-profile-update'),
    path('password_reset/', auth_views.PasswordResetView.as_view(template_name='researcher_page/password_reset.html'), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('password_reset_confirm/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('password_reset_complete/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),

]
