from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser
from staff.models import Staff
from .manager import CustomUserManager
from django.utils import timezone

class CustomUser(AbstractUser):
    USER_TYPE_CHOICES = [
        ('researcher', 'Researcher'),
        ('staff_admin', 'Staff Admin'),
        ('super_admin', ' Super Admin'),
    ]
    role=models.CharField(max_length=255,choices=USER_TYPE_CHOICES,  default='researcher')
    address = models.CharField(max_length=255, blank=True)
    staff=models.ForeignKey(Staff, on_delete=models.PROTECT,null=True ,blank=True)
    phone = models.CharField(max_length=15, blank=True)
    middle_name = models.CharField(max_length=50, blank=True)
    email = models.EmailField(unique=True) 
    username = None  
    image = models.ImageField(upload_to='profile_images/', default='default.jpg')
    username = None  
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    def __str__(self):
        return self.email
    
class Researcher(models.Model):
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
    ]

    ACADEMIC_STATUS_CHOICES = [
        ('Bsc', 'Bachelor of Science'),
        ('MSc', 'Master of Science'),
        ('PhD', 'Doctor of Philosophy'),
        ('Professor', 'Professor'),
    ]

    FACULTY_CHOICES = [
        ('Computing', 'Computing'),
        ('Electrical and Computer Engineering', 'Electrical and Computer Engineering'),
        ('Chemical and Food Engineering', 'Chemical and Food Engineering'),
        ('Mechanical and Industrial Engineering', 'Mechanical and Industrial Engineering'),
        ('Material Science Engineering', 'Material Science Engineering'),
    ]
    sponsorship = models.CharField(max_length=20, choices=[
        ('GOVERNMENTAL', 'Governmental'),
        ('NON GOVERNMENTAL', 'Non governmental'),
        ('PRIVATE', 'Private'),
    ], blank=True)
    institution_name_or_company_name = models.CharField(max_length=255, blank=True)
    user=models.OneToOneField(CustomUser,on_delete=models.CASCADE,primary_key=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    academic_status = models.CharField(max_length=10, choices=ACADEMIC_STATUS_CHOICES)
    faculty = models.CharField(max_length=100, choices=FACULTY_CHOICES)
    department = models.CharField(max_length=100)
    field_of_study = models.CharField(max_length=100)
    thematic_area = models.CharField(max_length=100)
    sub_thematic_area = models.CharField(max_length=100)
    identity_id = models.ImageField(upload_to='identity_pictures/')
    research_approval_letter = models.ImageField(upload_to='approval_letters/' ,default='default.jpg')

    def __str__(self):
            return self.user.first_name

class PermissionDelegation(models.Model):
    delegator=models.ForeignKey(CustomUser,on_delete=models.CASCADE,related_name="delegated_permissions")
    delegatee=models.ForeignKey(CustomUser,on_delete=models.CASCADE, related_name="received_permissions")
    permission=models.CharField(max_length=255)
    start_date=models.DateTimeField(default=timezone.now)
    end_date=models.DateTimeField(null=True,blank=True)
    
    def is_active(self):
        return self.end_date  is None or self.end_date>timezone.now()